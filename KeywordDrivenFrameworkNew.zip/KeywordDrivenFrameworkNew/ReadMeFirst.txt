You Need to Add the Selenium Library Files To the Project

Team Guru99